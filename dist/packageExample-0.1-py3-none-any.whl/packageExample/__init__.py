def tostr( list_str) :
    # print("This function will return a string from a list")
    return " ".join(list_str)

