from setuptools import setup
setup(name="packageExample",
version = "0.3",
description="This is a utility package to convert list to str",
long_description="This is a utility package to convert list to str.No other specific descriptions to mention",
author="Piyush",
packages=['packageExample'],
install_requires=[])